import Page from './Page'

export default Page
