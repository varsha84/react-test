import ProposalList from './ProposalList'

export default ProposalList
