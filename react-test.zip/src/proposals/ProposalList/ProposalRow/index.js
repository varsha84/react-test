import ProposalRow from './ProposalRow'

export default ProposalRow
