import ProposalDetails from './ProposalDetails'

export default ProposalDetails
