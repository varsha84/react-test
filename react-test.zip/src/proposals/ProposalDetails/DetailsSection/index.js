import DetailsSection from './DetailsSection'

export default DetailsSection